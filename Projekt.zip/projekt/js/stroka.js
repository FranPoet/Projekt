function openNav() {
  document.getElementById("mySidenav").style.width = "370px";
}

function closeNav() {
  document.getElementById("mySidenav").style.width = "0";
}


function openNav1() {
  document.getElementById("mySidenav").style.width = "300px";
}

$(function() { $('.marquee').marquee({ duration: 15000, startVisible: true, duplicated: true, hoverstop: true, inverthover: false }); });
