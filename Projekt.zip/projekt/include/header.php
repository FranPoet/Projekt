<html>
	<head>
		  <meta name="author" content="Roman Kukurudz">
			<meta charset="UTF-8">
			<meta name="viewport" content="width=device-width, initial-scale=1">
			<link rel = "stylesheet" type = "text/css" href = "css/style.css">
			<link rel="stylesheet" href="css/liMarquee.css"/>
		  <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.7.1/jquery.min.js"></script>
		  <script src="https://cdn.jsdelivr.net/jquery.marquee/1.4.0/jquery.marquee.min.js"></script>
		  <script src="js/stroka.js"></script>
	</head>

  <body>

	

	<header>	

			<div class = "header">

				<div class = "logo"><a class = "link" href="#">company</a></div>
				<div class = "description">Your technology partner in the web development</div>
				

				<div class = "menu">		
					<ul>
						<li><a class = "link menu_drive" href="#">services</a></li>
						<li><a class = "link menu_drive" href="#">engagement models</a></li>
						<li><a class = "link menu_drive" href="#">case studies</a></li>
						<li class = "contakt menu_drive"><a class = "link" href="#">Contact us</a></li>
						<li><span style="font-size:30px;cursor:pointer" onclick="openNav()"><img src = "css/gamburger.png"></span></li>
					</ul>
				</div>


				<div id="mySidenav" class="sidenav">
				  <a style = "border-bottom:0px;" href="javascript:void(0)" class="closebtn" onclick="closeNav()">&times;</a>
				  <a href="#">About</a>
				  <a href="#">Services</a>
				  <a href="#">Clients</a>
				  <a href="#">Contact</a>
				</div>



				<div class = "menu_mobile">		
					<ul>
						<li><span style="font-size:30px;cursor:pointer" onclick="openNav1()"><img class = "mobi_menu" src = "css/gamburger.png"></span></li>
					</ul>
				</div>

        <div class = "hralign">
				<div class = "hrdiv"></div>
			</div>
				
			</div>

	</header>

