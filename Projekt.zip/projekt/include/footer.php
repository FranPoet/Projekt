
<div class = "hrblock"></div>


<div class='marquee' style='overflow:hidden'>
	<a href="#"><img src="css/s1.png" class="img_s" /></a>
	<a href="#"><img src="css/s2.png" class="img_s" /></a>
	<a href="#"><img src="css/s3.png" class="img_s" /></a> 
	<a href="#"><img src="css/s4.png" class="img_s" /></a> 
	<a href="#"><img src="css/s5.png" class="img_s" /></a> 
	<a href="#"><img src="css/s6.png" class="img_s" /></a>
	<a href="#"><img src="css/s1.png" class="img_s" /></a>
	<a href="#"><img src="css/s2.png" class="img_s" /></a>
	<a href="#"><img src="css/s3.png" class="img_s" /></a> 
	<a href="#"><img src="css/s4.png" class="img_s" /></a> 
	<a href="#"><img src="css/s5.png" class="img_s" /></a> 
	<a href="#"><img src="css/s6.png" class="img_s" /></a>
</div>



</div>





</body>
</html>