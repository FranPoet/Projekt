<?php include "include/header.php"; ?>
    

        <div class = "baner">
        	<div class = "title"><div class="type">web</div></div>
        	<div class = "title2"><div class="type">development</div></div>
        </div>

      
		<div class = "section_3">
			
			<div class = "left_block">
				<div class = "align_description_text">
			          
                                     
				   Wordpress / Woocommerce project of any scale. HTML Layout of any complexity. Technical SEO optimization. PageSpeed / Core Vitals.

				
			
			       <a href = "#" class = "get_a_quote"><div class = "button_red">Get a quote</div></a>
				</div>
			</div>


		    <div class = "right_block">
			  <div class = "logo_grid_row_1">
					<div><a href = "#"><img src = "css/worpress.png" class = "sizeimg blink"></a></div>
					<div><a href = "#"><img src = "css/woocommerce.png" class = "sizeimg blink"></a></div>
					<div><a href = "#"><img src = "css/html.png" class = "sizeimg1 blink"></a></div>
				</div>
				<div class = "logo_grid_row_2">
					<div><a href = "#"><img src = "css/seo.png" class = "sizeimg blink"></a></div>
					<div><a href = "#"><img src = "css/Group.png" class = "sizeimg blink"></a></div>
					<div><a href = "#"><img src = "css/figma.png" class = "sizeimg blink"></a></div>
				</div>
				 <div class = "hrblock1"></div>
		    </div>

		</div>


<?php include "include/footer.php"; ?>



